class Animation{

  constructor(scene){this.scene = scene;}
	update(t){}
	apply(){}
};
