:- use_module(library(random)).


%play
play :-
	clearScreen,
	mainMenu.