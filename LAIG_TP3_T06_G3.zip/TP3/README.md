# LAIG 2020/2021 - TP3

## Group: T6xG03

| Name             | Number    | E-Mail             |
| ---------------- | --------- | ------------------ |
| Carolina Guilhermino        | 201800171 | up201800171@fe.up.pt |

